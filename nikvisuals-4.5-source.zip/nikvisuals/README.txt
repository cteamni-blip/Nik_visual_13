Nik Visuals 4.1.1

Fixes requested (no post-extract patch needed):
1) Removed missing SlotTimerRenderer.tick() call from NikVisualsClient
2) Partial tick only via RenderTickCounter.getTickProgress(true)
3) TargetHUD skin from PlayerListEntry.getSkinTextures() (+ PlayerSkinDrawer)

Build on PC:
  gradlew.bat build
  -> build\libs\nikvisuals-4.1.1.jar

Note: sandbox Gradle Loom OOM — full compile should be run on your machine.
