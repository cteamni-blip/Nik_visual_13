package com.nik.visuals.client.swap;

import com.nik.visuals.client.config.ModConfig;
import com.nik.visuals.client.render.GuiDraw;
import com.nik.visuals.client.theme.Style;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.slot.SlotActionType;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

@Environment(EnvType.CLIENT)
public class TalismanSwapHandler {
    private static final String[] ALLOWED = {
            "талисман крушителя", "талисман карателя", "талисман раздора", "талисман тирана",
            "талисман ярости", "талисман вихря", "талисман мрака", "талисман демона",
            "сфера афины", "сфера титана", "сфера хаоса", "сфера сатира", "сфера бестии",
            "сфера ареса", "сфера гидры", "сфера икара", "сфера эрида"
    };

    private static final long SWAP_COOLDOWN_MS = 350L;
    private long lastSwapMs;
    private boolean wasDown;
    private int hovered = -1;
    private final List<Candidate> candidates = new ArrayList<>();
    private float openAnim;
    private float spin;
    private String statusMsg;
    private long statusUntil;
    private int freezeTicks;
    private float burst;

    // saved movement so we can restore after swap
    private boolean savFwd, savBack, savLeft, savRight, savJump, savSprint;
    private boolean keysSaved;

    public void tick(MinecraftClient mc, boolean keyDown) {
        if (freezeTicks > 0) {
            freezeTicks--;
            forceStop(mc);
            if (freezeTicks == 0) {
                restoreKeys(mc);
            }
        }

        if (!ModConfig.talismanSwap || mc.player == null || mc.currentScreen != null) {
            if (wasDown || keysSaved) restoreKeys(mc);
            wasDown = false;
            candidates.clear();
            hovered = -1;
            openAnim = Math.max(0f, openAnim - 0.2f);
            return;
        }

        if (keyDown) {
            if (!wasDown) {
                saveKeys(mc);
                rebuildCandidates(mc.player);
                hovered = candidates.isEmpty() ? -1 : 0;
            }
            updateHover(mc);
            openAnim = Math.min(1f, openAnim + 0.18f);
            spin += 0.04f;
            forceStop(mc);
            wasDown = true;
        } else {
            if (wasDown && hovered >= 0 && hovered < candidates.size()) {
                trySwap(mc, candidates.get(hovered));
            } else if (wasDown) {
                restoreKeys(mc);
            }
            wasDown = false;
            candidates.clear();
            hovered = -1;
            openAnim = Math.max(0f, openAnim - 0.22f);
        }
    }

    private void saveKeys(MinecraftClient mc) {
        if (mc.options == null) return;
        savFwd = mc.options.forwardKey.isPressed();
        savBack = mc.options.backKey.isPressed();
        savLeft = mc.options.leftKey.isPressed();
        savRight = mc.options.rightKey.isPressed();
        savJump = mc.options.jumpKey.isPressed();
        savSprint = mc.options.sprintKey.isPressed();
        keysSaved = true;
    }

    private void restoreKeys(MinecraftClient mc) {
        if (!keysSaved || mc.options == null) return;
        setKey(mc.options.forwardKey, savFwd);
        setKey(mc.options.backKey, savBack);
        setKey(mc.options.leftKey, savLeft);
        setKey(mc.options.rightKey, savRight);
        setKey(mc.options.jumpKey, savJump);
        setKey(mc.options.sprintKey, savSprint);
        keysSaved = false;
    }

    private void setKey(KeyBinding kb, boolean down) {
        try { kb.setPressed(down); } catch (Throwable ignored) {}
    }

    private void forceStop(MinecraftClient mc) {
        try {
            if (mc.player == null || mc.options == null) return;
            mc.options.forwardKey.setPressed(false);
            mc.options.backKey.setPressed(false);
            mc.options.leftKey.setPressed(false);
            mc.options.rightKey.setPressed(false);
            mc.options.jumpKey.setPressed(false);
            mc.options.sprintKey.setPressed(false);
            // zero horizontal velocity — keep vertical mild
            var v = mc.player.getVelocity();
            mc.player.setVelocity(0, Math.min(v.y, 0), 0);
        } catch (Throwable ignored) {}
    }

    private void trySwap(MinecraftClient mc, Candidate c) {
        long now = System.currentTimeMillis();
        if (now - lastSwapMs < SWAP_COOLDOWN_MS) {
            statusMsg = "§cПодожди…";
            statusUntil = now + 500;
            restoreKeys(mc);
            return;
        }
        forceStop(mc);
        if (swapOffhandOnce(mc, c)) {
            lastSwapMs = now;
            freezeTicks = 4; // restore keys after short freeze
            statusMsg = "§a" + c.displayName;
            burst = 1f;
            statusUntil = now + 800;
        } else {
            statusMsg = "§cНе вышло";
            statusUntil = now + 600;
            restoreKeys(mc);
        }
    }

    private boolean swapOffhandOnce(MinecraftClient mc, Candidate c) {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.interactionManager == null) return false;
        try {
            ItemStack cur = p.getInventory().getStack(c.invSlot);
            if (cur.isEmpty() || !isAllowed(cur)) return false;
            if (ItemStack.areItemsAndComponentsEqual(p.getOffHandStack(), cur)) return true;

            int syncId = p.currentScreenHandler != null ? p.currentScreenHandler.syncId : p.playerScreenHandler.syncId;
            int containerSlot = c.invSlot < 9 ? 36 + c.invSlot : c.invSlot;
            mc.interactionManager.clickSlot(syncId, containerSlot, 40, SlotActionType.SWAP, p);
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    private void rebuildCandidates(ClientPlayerEntity player) {
        candidates.clear();
        Map<String, Candidate> uniq = new LinkedHashMap<>();
        ItemStack off = player.getOffHandStack();
        String offKey = (!off.isEmpty() && isAllowed(off)) ? normalize(off.getName().getString()) : "";

        // Unique allowed items from inventory/hotbar.
        // If this talisman/sphere is already in the offhand — do not show it in the ring.
        for (int i = 0; i < 36; i++) {
            ItemStack st = player.getInventory().getStack(i);
            if (st.isEmpty() || !isAllowed(st)) continue;
            String key = normalize(st.getName().getString());
            if (key.isEmpty()) continue;
            if (!offKey.isEmpty() && key.equals(offKey)) continue; // already in left hand
            if (uniq.containsKey(key)) continue;
            String display = st.getName().getString().replaceAll("§.", "");
            uniq.put(key, new Candidate(i, st.copy(), display));
        }
        candidates.addAll(uniq.values());
    }

    public static boolean isAllowed(ItemStack stack) {
        if (stack == null || stack.isEmpty()) return false;
        String name = normalize(stack.getName().getString());
        for (String a : ALLOWED) {
            if (name.equals(a) || name.contains(a)) return true;
        }
        return false;
    }

    private static String normalize(String s) {
        return s.replaceAll("§.", "").toLowerCase(Locale.ROOT).trim();
    }

    private void updateHover(MinecraftClient mc) {
        if (candidates.isEmpty()) { hovered = -1; return; }
        double mx = mc.mouse.getX() * mc.getWindow().getScaledWidth() / Math.max(1.0, mc.getWindow().getWidth());
        double my = mc.mouse.getY() * mc.getWindow().getScaledHeight() / Math.max(1.0, mc.getWindow().getHeight());
        int cx = mc.getWindow().getScaledWidth() / 2;
        int cy = mc.getWindow().getScaledHeight() / 2;
        int n = candidates.size();
        double radius = 74;
        int best = -1;
        double bestDist = Double.MAX_VALUE;
        for (int i = 0; i < n; i++) {
            double ang = -Math.PI / 2.0 + (Math.PI * 2.0 * i / n);
            double ix = cx + Math.cos(ang) * radius;
            double iy = cy + Math.sin(ang) * radius;
            double d = (mx - ix) * (mx - ix) + (my - iy) * (my - iy);
            if (d < bestDist) { bestDist = d; best = i; }
        }
        double cdx = mx - cx, cdy = my - cy;
        if (cdx * cdx + cdy * cdy < 22 * 22) {
            if (hovered < 0) hovered = best;
            return;
        }
        hovered = best;
    }

    public void render(DrawContext g, float pt) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;
        long now = System.currentTimeMillis();
        if (statusMsg != null && now < statusUntil) {
            g.drawCenteredTextWithShadow(mc.textRenderer, statusMsg,
                    mc.getWindow().getScaledWidth() / 2,
                    mc.getWindow().getScaledHeight() / 2 + 72, 0xFFFFFFFF);
        }
        burst = Math.max(0f, burst - 0.05f);
        if (burst > 0.05f) {
            int cx = mc.getWindow().getScaledWidth() / 2;
            int cy = mc.getWindow().getScaledHeight() / 2;
            for (int i = 0; i < 10; i++) {
                double ang = i * Math.PI * 2 / 10.0 + burst * 3;
                int rr = (int) (20 + (1f - burst) * 30);
                GuiDraw.fillSoftCircle(g, cx + (int)(Math.cos(ang)*rr), cy + (int)(Math.sin(ang)*rr), 2,
                        Style.alpha(Style.ACCENT, burst));
            }
        }
        if (openAnim < 0.02f || candidates.isEmpty()) return;

        float a = openAnim;
        int cx = mc.getWindow().getScaledWidth() / 2;
        int cy = mc.getWindow().getScaledHeight() / 2;
        int n = candidates.size();
        double radius = 74 + 5 * Math.sin(spin * 2);

        drawRing(g, cx, cy, (int) radius + 20, 18, Style.alpha(0xFF101010, a * 0.92f));
        drawRing(g, cx, cy, (int) radius + 20, 2, Style.alpha(Style.ACCENT, a * 0.7f));
        GuiDraw.fillSoftCircle(g, cx, cy, 24, Style.alpha(Style.PANEL, a));
        GuiDraw.fillSoftCircle(g, cx, cy, 22, Style.alpha(0xFF0A0A0A, a));
        String tip = hovered >= 0 && hovered < n ? candidates.get(hovered).displayName : "Выбор";
        if (tip.length() > 18) tip = tip.substring(0, 17) + "…";
        g.drawCenteredTextWithShadow(mc.textRenderer, tip, cx, cy - 4, Style.alpha(Style.TEXT, a));
        g.drawCenteredTextWithShadow(mc.textRenderer, "отпусти", cx, cy + 8, Style.alpha(Style.TEXT_DIM, a));

        for (int i = 0; i < n; i++) {
            double ang = -Math.PI / 2 + (Math.PI * 2 * i / n);
            int ix = cx + (int) (Math.cos(ang) * radius);
            int iy = cy + (int) (Math.sin(ang) * radius);
            boolean hot = i == hovered;
            int size = hot ? 18 : 14;
            GuiDraw.fillSoftCircle(g, ix, iy, size + 5,
                    Style.alpha(hot ? Style.ACCENT : 0xFF1C1C1C, a * (hot ? 0.9f : 0.6f)));
            GuiDraw.fillSoftCircle(g, ix, iy, size + 1, Style.alpha(Style.PANEL, a));
            g.drawItem(candidates.get(i).stack, ix - 8, iy - 8);
            if (hot) {
                for (int p = 0; p < 6; p++) {
                    double pa = spin * 3 + p * (Math.PI * 2 / 6.0);
                    GuiDraw.fillSoftCircle(g,
                            ix + (int) (Math.cos(pa) * (size + 7)),
                            iy + (int) (Math.sin(pa) * (size + 7)),
                            1, Style.alpha(Style.ACCENT, a * 0.75f));
                }
            }
        }
    }

    private void drawRing(DrawContext g, int cx, int cy, int r, int thick, int color) {
        int steps = 52;
        for (int i = 0; i < steps; i++) {
            double a0 = (Math.PI * 2 * i) / steps;
            double a1 = (Math.PI * 2 * (i + 1)) / steps;
            for (int t = 0; t < thick; t++) {
                int rr = r - t;
                int x0 = cx + (int) (Math.cos(a0) * rr);
                int y0 = cy + (int) (Math.sin(a0) * rr);
                int x1 = cx + (int) (Math.cos(a1) * rr);
                int y1 = cy + (int) (Math.sin(a1) * rr);
                g.fill(Math.min(x0, x1), Math.min(y0, y1), Math.max(x0, x1) + 1, Math.max(y0, y1) + 1, color);
            }
        }
    }

    private static final class Candidate {
        final int invSlot;
        final ItemStack stack;
        final String displayName;
        Candidate(int invSlot, ItemStack stack, String displayName) {
            this.invSlot = invSlot;
            this.stack = stack;
            this.displayName = displayName;
        }
    }
}
