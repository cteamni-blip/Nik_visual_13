package com.nik.visuals.client.music;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.nik.visuals.client.config.ModConfig;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicReference;

@Environment(EnvType.CLIENT)
public class MusicService {
    public static final class Track {
        public String title = "Нет трека";
        public String artist = "";
        public String source = "";
        public String coverUrl = "";
        public long durationMs;
        public long positionMs;
        public boolean playing;
        public long updatedAt;
    }

    private final AtomicReference<Track> track = new AtomicReference<>(new Track());
    private final ExecutorService pool = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "nik-music");
        t.setDaemon(true);
        return t;
    });
    private long lastPoll;
    private float smoothPos;

    public Track get() { return track.get(); }

    public float smoothProgress() {
        Track t = track.get();
        if (t.durationMs <= 0) return 0f;
        long pos = t.positionMs;
        if (t.playing) pos += Math.max(0, System.currentTimeMillis() - t.updatedAt);
        smoothPos = smoothPos * 0.85f + (pos / (float) t.durationMs) * 0.15f;
        return Math.max(0f, Math.min(1f, smoothPos));
    }

    public void tick() {
        if (!ModConfig.musicHud) return;
        long now = System.currentTimeMillis();
        if (now - lastPoll < 1200) return;
        lastPoll = now;
        pool.execute(this::poll);
    }

    private void poll() {
        try {
            String url = (ModConfig.musicBridgeUrl == null || ModConfig.musicBridgeUrl.isEmpty())
                    ? "http://127.0.0.1:1764/now" : ModConfig.musicBridgeUrl;
            HttpURLConnection c = (HttpURLConnection) URI.create(url).toURL().openConnection();
            c.setConnectTimeout(400);
            c.setReadTimeout(600);
            c.setRequestMethod("GET");
            if (c.getResponseCode() != 200) return;
            try (BufferedReader br = new BufferedReader(new InputStreamReader(c.getInputStream(), StandardCharsets.UTF_8))) {
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = br.readLine()) != null) sb.append(line);
                JsonObject o = JsonParser.parseString(sb.toString()).getAsJsonObject();
                Track t = new Track();
                t.title = o.has("title") ? o.get("title").getAsString() : "Unknown";
                t.artist = o.has("artist") ? o.get("artist").getAsString() : "";
                t.source = o.has("source") ? o.get("source").getAsString() : "";
                t.coverUrl = o.has("coverUrl") ? o.get("coverUrl").getAsString() : "";
                t.durationMs = o.has("durationMs") ? o.get("durationMs").getAsLong() : 0;
                t.positionMs = o.has("positionMs") ? o.get("positionMs").getAsLong() : 0;
                t.playing = o.has("playing") && o.get("playing").getAsBoolean();
                t.updatedAt = System.currentTimeMillis();
                track.set(t);
            }
        } catch (Throwable ignored) {}
    }

    public void sendCommand(String cmd) {
        if (!ModConfig.musicHud) return;
        pool.execute(() -> {
            try {
                String control = "http://127.0.0.1:1764/control?action=" + cmd;
                HttpURLConnection c = (HttpURLConnection) URI.create(control).toURL().openConnection();
                c.setConnectTimeout(400);
                c.setReadTimeout(400);
                c.setRequestMethod("POST");
                c.getResponseCode();
            } catch (Throwable ignored) {}
        });
    }
}
