package com.nik.visuals.client.render;

import com.nik.visuals.client.config.ModConfig;
import com.nik.visuals.client.theme.Style;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

@Environment(EnvType.CLIENT)
public class ShieldHudRenderer {
    public void render(DrawContext g, float pt) {
        if (!ModConfig.shieldHud) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.options.hudHidden) return;
        ItemStack off = mc.player.getOffHandStack();
        ItemStack main = mc.player.getMainHandStack();
        ItemStack shield = off.isOf(Items.SHIELD) ? off : (main.isOf(Items.SHIELD) ? main : ItemStack.EMPTY);
        if (shield.isEmpty()) return;

        int x = mc.getWindow().getScaledWidth() / 2 - 120;
        int y = mc.getWindow().getScaledHeight() - 40;
        float max = shield.getMaxDamage();
        float left = max - shield.getDamage();
        float pct = max <= 0 ? 1f : left / max;
        GuiDraw.glassPanel(g, x, y, 42, 18, 6, Style.PANEL, Style.ACCENT_GLOW);
        g.drawItem(shield, x + 2, y + 1);
        GuiDraw.hpBar(g, x + 20, y + 6, 18, 6, pct,
                pct > 0.3f ? Style.OK : Style.DANGER, Style.TRACK_OFF);
    }
}
