package com.nik.visuals.client.gui;

import com.nik.visuals.client.config.ModConfig;
import com.nik.visuals.client.render.GuiDraw;
import com.nik.visuals.client.theme.Anim;
import com.nik.visuals.client.theme.Style;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public class TrajectorySettingsScreen extends Screen {
    private static final int[] PALETTE = {
            0xFFFFFFFF, 0xFF55AAFF, 0xFF3DCC7A, 0xFFFFCC33,
            0xFFFF5555, 0xFFFF66AA, 0xFFAA88FF, 0xFF88EEFF,
            0xFFB0B0B0, 0xFF1A6ACC, 0xFF1A8F5A, 0xFFCC6600
    };
    private final Screen parent;
    private float openA;
    private int px, py, pw, ph;
    private int drag = -1;

    public TrajectorySettingsScreen(Screen parent) {
        super(Text.literal("Траектория"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        openA = 0;
        pw = 280; ph = 220;
        px = (width - pw) / 2;
        py = (height - ph) / 2;
    }

    @Override
    public void render(DrawContext g, int mx, int my, float delta) {
        openA = Anim.approach(openA, 1f, 0.16f);
        float a = Anim.easeOutCubic(openA);
        g.fill(0, 0, width, height, Style.solidAlpha(0x000000, (int) (150 * a)));
        GuiDraw.fillRounded(g, px, py, pw, ph, 10, Style.alpha(Style.PANEL, a));
        g.fill(px, py, px + pw, py + 1, Style.alpha(Style.ACCENT, a * 0.5f));

        g.drawText(textRenderer, "Настройка траектории", px + 14, py + 12, Style.alpha(Style.TEXT, a), false);

        // enable
        g.drawText(textRenderer, "Включена", px + 14, py + 36, Style.alpha(Style.TEXT, a), false);
        GuiDraw.toggle(g, px + pw - 40, py + 35, 22, 12, ModConfig.trajectory ? 1f : 0f,
                Style.alpha(Style.ACCENT, a), Style.alpha(Style.TRACK_OFF, a), Style.alpha(Style.KNOB, a));

        g.drawText(textRenderer, "Цвет линии", px + 14, py + 58, Style.alpha(Style.TEXT_DIM, a), false);
        int cell = 16, gap = 4;
        for (int i = 0; i < PALETTE.length; i++) {
            int cx = px + 14 + (i % 6) * (cell + gap);
            int cy = py + 74 + (i / 6) * (cell + gap);
            boolean sel = (ModConfig.trajectoryColor & 0xFFFFFF) == (PALETTE[i] & 0xFFFFFF);
            GuiDraw.fillRounded(g, cx - 1, cy - 1, cell + 2, cell + 2, 3,
                    Style.alpha(sel ? Style.ACCENT : 0xFF222222, a));
            g.fill(cx, cy, cx + cell, cy + cell, 0xFF000000 | (PALETTE[i] & 0xFFFFFF));
        }

        g.drawText(textRenderer, "Толщина (визуально)", px + 14, py + 130, Style.alpha(Style.TEXT_DIM, a), false);
        // thickness as 1-3 via simple bars
        for (int i = 1; i <= 3; i++) {
            int bx = px + 14 + (i - 1) * 36;
            boolean on = ModConfig.trajectoryThickness == i;
            GuiDraw.fillRounded(g, bx, py + 146, 30, 14, 4, Style.alpha(on ? Style.ACCENT : 0xFF1A1A1A, a));
            g.drawCenteredTextWithShadow(textRenderer, String.valueOf(i), bx + 15, py + 149, Style.alpha(Style.TEXT, a));
        }

        g.drawText(textRenderer, "Сфера на конце", px + 14, py + 170, Style.alpha(Style.TEXT, a), false);
        GuiDraw.toggle(g, px + pw - 40, py + 169, 22, 12, ModConfig.trajectoryEndSphere ? 1f : 0f,
                Style.alpha(Style.ACCENT, a), Style.alpha(Style.TRACK_OFF, a), Style.alpha(Style.KNOB, a));

        int bx = px + pw / 2 - 40;
        int by = py + ph - 24;
        boolean hov = mx >= bx && mx <= bx + 80 && my >= by && my <= by + 14;
        GuiDraw.fillRounded(g, bx, by, 80, 14, 4, Style.alpha(hov ? Style.ACCENT : 0xFF1E1E1E, a));
        g.drawCenteredTextWithShadow(textRenderer, "Готово", bx + 40, by + 3, Style.alpha(Style.TEXT, a));
        super.render(g, mx, my, delta);
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        double mx = click.x(), my = click.y();
        int bx = px + pw / 2 - 40, by = py + ph - 24;
        if (mx >= bx && mx <= bx + 80 && my >= by && my <= by + 14) { close(); return true; }
        if (mx >= px + pw - 40 && mx <= px + pw - 18 && my >= py + 35 && my <= py + 47) {
            ModConfig.trajectory = !ModConfig.trajectory; ModConfig.save(); return true;
        }
        if (mx >= px + pw - 40 && mx <= px + pw - 18 && my >= py + 169 && my <= py + 181) {
            ModConfig.trajectoryEndSphere = !ModConfig.trajectoryEndSphere; ModConfig.save(); return true;
        }
        int cell = 16, gap = 4;
        for (int i = 0; i < PALETTE.length; i++) {
            int cx = px + 14 + (i % 6) * (cell + gap);
            int cy = py + 74 + (i / 6) * (cell + gap);
            if (mx >= cx && mx <= cx + cell && my >= cy && my <= cy + cell) {
                ModConfig.trajectoryColor = PALETTE[i]; ModConfig.save(); return true;
            }
        }
        for (int i = 1; i <= 3; i++) {
            int x = px + 14 + (i - 1) * 36;
            if (mx >= x && mx <= x + 30 && my >= py + 146 && my <= py + 160) {
                ModConfig.trajectoryThickness = i; ModConfig.save(); return true;
            }
        }
        return super.mouseClicked(click, doubled);
    }

    @Override
    public boolean keyPressed(KeyInput input) {
        if (input.key() == GLFW.GLFW_KEY_ESCAPE) { close(); return true; }
        return super.keyPressed(input);
    }

    @Override
    public void close() {
        ModConfig.save();
        if (client != null) client.setScreen(parent);
    }

    @Override
    public boolean shouldPause() { return false; }
}
