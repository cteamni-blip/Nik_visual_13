package com.nik.visuals.client.render;

import com.nik.visuals.client.config.ModConfig;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

@Environment(EnvType.CLIENT)
public class CrosshairRenderer {
    public void render(DrawContext g, float pt) {
        if (!ModConfig.customCrosshair) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.options.hudHidden || mc.currentScreen != null) return;

        int cx = mc.getWindow().getScaledWidth() / 2;
        int cy = mc.getWindow().getScaledHeight() / 2;
        int col = 0xFF000000 | (ModConfig.crosshairColor & 0xFFFFFF);
        int outline = ModConfig.crosshairOutline ? 0xFF000000 : 0;
        int size = Math.max(1, Math.min(16, ModConfig.crosshairSize));
        int gap = Math.max(0, Math.min(12, ModConfig.crosshairGap));
        int th = Math.max(1, Math.min(4, ModConfig.crosshairThickness));
        int dot = Math.max(0, Math.min(6, ModConfig.crosshairDotSize));
        double ang = Math.toRadians(ModConfig.crosshairAngle);

        // Classic cross: 4 arms + optional center dot, rotated as one shape
        if (ModConfig.crosshairLeft) arm(g, cx, cy, -gap - size, -th / 2.0, size, th, ang, col, outline);
        if (ModConfig.crosshairRight) arm(g, cx, cy, gap + 1, -th / 2.0, size, th, ang, col, outline);
        if (ModConfig.crosshairTop) arm(g, cx, cy, -th / 2.0, -gap - size, th, size, ang, col, outline);
        if (ModConfig.crosshairBottom) arm(g, cx, cy, -th / 2.0, gap + 1, th, size, ang, col, outline);

        if (ModConfig.crosshairDot && dot > 0) {
            double hx = -dot / 2.0, hy = -dot / 2.0;
            if (outline != 0) fillRot(g, cx, cy, hx - 1, hy - 1, dot + 2, dot + 2, ang, outline);
            fillRot(g, cx, cy, hx, hy, dot, dot, ang, col);
        }
    }

    private void arm(DrawContext g, int cx, int cy, double x, double y, double w, double h,
                     double ang, int col, int outline) {
        if (outline != 0) fillRot(g, cx, cy, x - 1, y - 1, w + 2, h + 2, ang, outline);
        fillRot(g, cx, cy, x, y, w, h, ang, col);
    }

    private void fillRot(DrawContext g, int cx, int cy, double x, double y, double w, double h,
                         double ang, int col) {
        if (w <= 0 || h <= 0) return;
        double cos = Math.cos(ang), sin = Math.sin(ang);
        // corners of rect in local space, rotate, draw bounding raster
        double[] xs = {x, x + w, x + w, x};
        double[] ys = {y, y, y + h, y + h};
        int minX = Integer.MAX_VALUE, minY = Integer.MAX_VALUE, maxX = Integer.MIN_VALUE, maxY = Integer.MIN_VALUE;
        for (int i = 0; i < 4; i++) {
            double rx = xs[i] * cos - ys[i] * sin;
            double ry = xs[i] * sin + ys[i] * cos;
            minX = Math.min(minX, (int) Math.floor(rx));
            maxX = Math.max(maxX, (int) Math.ceil(rx));
            minY = Math.min(minY, (int) Math.floor(ry));
            maxY = Math.max(maxY, (int) Math.ceil(ry));
        }
        // clamp work area
        if (maxX - minX > 48 || maxY - minY > 48) {
            // fallback axis box at center for extreme cases
            g.fill(cx + (int) x, cy + (int) y, cx + (int) (x + w), cy + (int) (y + h), col);
            return;
        }
        for (int py = minY; py <= maxY; py++) {
            for (int px = minX; px <= maxX; px++) {
                double lx = px * cos + py * sin;
                double ly = -px * sin + py * cos;
                if (lx >= x && lx < x + w && ly >= y && ly < y + h) {
                    g.fill(cx + px, cy + py, cx + px + 1, cy + py + 1, col);
                }
            }
        }
    }
}
