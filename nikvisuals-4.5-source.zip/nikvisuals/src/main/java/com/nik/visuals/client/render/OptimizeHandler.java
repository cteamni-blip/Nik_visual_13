package com.nik.visuals.client.render;

import com.nik.visuals.client.config.ModConfig;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.CloudRenderMode;

@Environment(EnvType.CLIENT)
public class OptimizeHandler {
    private CloudRenderMode savedClouds;
    private Boolean savedShadows;
    private Boolean savedViewBob;
    private Integer savedBiomeBlend;
    private boolean applied;

    public void tick(MinecraftClient mc) {
        if (mc == null || mc.options == null) return;
        try {
            if (ModConfig.optimizePvp) {
                if (!applied) {
                    try { savedClouds = mc.options.getCloudRenderMode().getValue(); } catch (Throwable ignored) {}
                    try { savedShadows = mc.options.getEntityShadows().getValue(); } catch (Throwable ignored) {}
                    try { savedViewBob = mc.options.getBobView().getValue(); } catch (Throwable ignored) {}
                    try { savedBiomeBlend = mc.options.getBiomeBlendRadius().getValue(); } catch (Throwable ignored) {}
                    applied = true;
                }
                try { mc.options.getCloudRenderMode().setValue(CloudRenderMode.OFF); } catch (Throwable ignored) {}
                try { mc.options.getEntityShadows().setValue(false); } catch (Throwable ignored) {}
                try { mc.options.getBobView().setValue(false); } catch (Throwable ignored) {}
                try { mc.options.getBiomeBlendRadius().setValue(0); } catch (Throwable ignored) {}
            } else if (applied) {
                try { if (savedClouds != null) mc.options.getCloudRenderMode().setValue(savedClouds); } catch (Throwable ignored) {}
                try { if (savedShadows != null) mc.options.getEntityShadows().setValue(savedShadows); } catch (Throwable ignored) {}
                try { if (savedViewBob != null) mc.options.getBobView().setValue(savedViewBob); } catch (Throwable ignored) {}
                try { if (savedBiomeBlend != null) mc.options.getBiomeBlendRadius().setValue(savedBiomeBlend); } catch (Throwable ignored) {}
                applied = false;
            }
        } catch (Throwable ignored) {}
    }
}
