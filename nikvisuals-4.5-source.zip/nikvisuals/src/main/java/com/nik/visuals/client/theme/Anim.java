package com.nik.visuals.client.theme;

public final class Anim {
    private Anim() {}

    public static float approach(float current, float target, float speed) {
        float d = target - current;
        if (Math.abs(d) < 0.0008f) return target;
        return current + d * clamp01(speed);
    }

    /** Spring-ish overshoot for pop-ins */
    public static float spring(float t) {
        t = clamp01(t);
        // ease out back
        float c1 = 1.70158f;
        float c3 = c1 + 1f;
        return 1f + c3 * (float) Math.pow(t - 1f, 3) + c1 * (float) Math.pow(t - 1f, 2);
    }

    public static float easeOutCubic(float t) {
        t = clamp01(t);
        float u = 1f - t;
        return 1f - u * u * u;
    }

    public static float easeOutQuad(float t) {
        t = clamp01(t);
        return 1f - (1f - t) * (1f - t);
    }

    public static float easeInOut(float t) {
        t = clamp01(t);
        return t < 0.5f ? 2f * t * t : 1f - (float) Math.pow(-2f * t + 2f, 2) / 2f;
    }

    public static float pulse(float speed) {
        return 0.5f + 0.5f * (float) Math.sin(System.currentTimeMillis() / 1000.0 * speed * Math.PI * 2);
    }

    public static int lerpColor(int a, int b, float t) {
        t = clamp01(t);
        int aa = (a >>> 24) & 0xFF, ar = (a >> 16) & 0xFF, ag = (a >> 8) & 0xFF, ab = a & 0xFF;
        int ba = (b >>> 24) & 0xFF, br = (b >> 16) & 0xFF, bg = (b >> 8) & 0xFF, bb = b & 0xFF;
        return (((int) (aa + (ba - aa) * t)) << 24)
             | (((int) (ar + (br - ar) * t)) << 16)
             | (((int) (ag + (bg - ag) * t)) << 8)
             |  ((int) (ab + (bb - ab) * t));
    }

    public static float clamp01(float v) {
        return v < 0f ? 0f : (Math.min(v, 1f));
    }
}
