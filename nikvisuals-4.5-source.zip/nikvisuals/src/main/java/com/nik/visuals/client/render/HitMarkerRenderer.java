package com.nik.visuals.client.render;

import com.nik.visuals.client.config.ModConfig;
import com.nik.visuals.client.theme.Anim;
import com.nik.visuals.client.theme.Style;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;

@Environment(EnvType.CLIENT)
public class HitMarkerRenderer {
    private float flash;
    private boolean wasSwing;

    public void tick(MinecraftClient mc) {
        if (!ModConfig.hitMarker || mc.player == null) {
            flash = Anim.approach(flash, 0f, 0.2f);
            return;
        }
        boolean swinging = mc.player.handSwinging;
        if (swinging && !wasSwing) {
            Entity focused = null;
            if (mc.crosshairTarget != null && mc.crosshairTarget.getType() == HitResult.Type.ENTITY) {
                focused = ((EntityHitResult) mc.crosshairTarget).getEntity();
            }
            if (focused instanceof LivingEntity le && le.isAlive()) {
                flash = 1f;
            }
        }
        wasSwing = swinging;
        flash = Anim.approach(flash, 0f, 0.14f);
    }

    public void render(DrawContext g, float pt) {
        if (flash < 0.04f) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        int cx = mc.getWindow().getScaledWidth() / 2;
        int cy = mc.getWindow().getScaledHeight() / 2;
        float a = flash;
        int col = Style.alpha(0xFFE8F5EC, a);
        int s = 4 + (int) (3 * flash);
        // small X / cross
        g.fill(cx - s, cy - 1, cx - 2, cy + 1, col);
        g.fill(cx + 2, cy - 1, cx + s, cy + 1, col);
        g.fill(cx - 1, cy - s, cx + 1, cy - 2, col);
        g.fill(cx - 1, cy + 2, cx + 1, cy + s, col);
        // soft corner marks
        int c = Style.alpha(Style.ACCENT, a * 0.85f);
        g.fill(cx - s - 1, cy - s - 1, cx - s + 2, cy - s + 2, c);
        g.fill(cx + s - 2, cy - s - 1, cx + s + 1, cy - s + 2, c);
        g.fill(cx - s - 1, cy + s - 2, cx - s + 2, cy + s + 1, c);
        g.fill(cx + s - 2, cy + s - 2, cx + s + 1, cy + s + 1, c);
    }
}
