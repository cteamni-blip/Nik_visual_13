package com.nik.visuals.client.render;

import com.nik.visuals.client.config.ModConfig;
import com.nik.visuals.client.theme.Anim;
import com.nik.visuals.client.theme.Style;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;

@Environment(EnvType.CLIENT)
public class CritEffectRenderer {
    private float flash;
    private boolean wasSwing;

    public void tick(MinecraftClient mc) {
        if (!ModConfig.critEffect || mc.player == null) { flash = 0; return; }
        boolean swinging = mc.player.handSwinging;
        if (swinging && !wasSwing) {
            boolean crit = mc.player.fallDistance > 0 && !mc.player.isOnGround()
                    && !mc.player.isClimbing() && !mc.player.isTouchingWater() && !mc.player.hasVehicle();
            if (crit && mc.crosshairTarget != null && mc.crosshairTarget.getType() == HitResult.Type.ENTITY) {
                Entity e = ((EntityHitResult) mc.crosshairTarget).getEntity();
                if (e instanceof LivingEntity) flash = 1f;
            }
        }
        wasSwing = swinging;
        flash = Anim.approach(flash, 0f, 0.12f);
    }

    public void render(DrawContext g, float pt) {
        if (flash < 0.05f) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        int cx = mc.getWindow().getScaledWidth() / 2;
        int cy = mc.getWindow().getScaledHeight() / 2;
        int a = (int) (180 * flash);
        int col = (a << 24) | 0xFFE8A0;
        int s = (int) (8 + 10 * flash);
        // diagonal streaks
        g.fill(cx - s, cy - s, cx - s + 3, cy - s / 2, col);
        g.fill(cx + s - 3, cy - s, cx + s, cy - s / 2, col);
        g.fill(cx - s, cy + s / 2, cx - s + 3, cy + s, col);
        g.fill(cx + s - 3, cy + s / 2, cx + s, cy + s, col);
    }
}
